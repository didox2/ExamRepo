﻿namespace OlympicGames.Olympics.Contracts
{
    public interface ICountry
    {
        string Country { get; }
    }
}
