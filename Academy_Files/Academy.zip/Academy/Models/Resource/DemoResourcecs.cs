﻿using Academy.Models.Enums;

namespace Academy.Models.Resource
{
    public class DemoResourcecs : LectureResource
    {
        public DemoResourcecs(string name, string url, ResourceType type) : base(name, url, type)
        {
        }
    }
}
