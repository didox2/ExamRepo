﻿namespace Academy.Models.Enums
{
    public enum Track
    {
        None,
        Frontend,
        Dev
    }
}
