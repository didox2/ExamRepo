﻿namespace Academy.Models.Enums
{
    public enum ResourceType
    {
        Demo = 0,
        Homework = 1,
        Presentation = 2,
        Video = 3
    }
}
