﻿namespace Academy.Models.Enums
{
    public enum Initiative
    {
        SoftwareAcademy = 0,
        SchoolAcademy = 1,
        KidsAcademy = 2,
        CoderDojo = 3
    }
}
