﻿using Academy.Models.Enums;

namespace Academy.Models.Contracts
{
    public interface IResourceType
    {
        ResourceType Type { get;}
    }
}
