﻿namespace Traveller.Models.Enumerations
{
    public enum VehicleType
    {
        Land = 0,
        Air,
        Sea
    }
}
