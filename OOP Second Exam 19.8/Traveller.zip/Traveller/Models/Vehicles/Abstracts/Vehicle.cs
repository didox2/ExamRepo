﻿using Traveller.Models.Enumerations;
using Traveller.Models.Vehicles.Contracts;
using Traveller.Utils;

namespace Traveller.Models.Vehicles.Abstracts
{
    public abstract class Vehicle : IVehicle
    {
        private int pasangerCapacity;
        private decimal pricePerKilometer;
        private VehicleType type;

        public Vehicle(int pasangerCapacity, decimal pricePerKilometer, VehicleType type)
        {
            this.PasangerCapacity = pasangerCapacity;
            this.PricePerKilometer = pricePerKilometer;
            this.Type = type;
        }

        public virtual int PasangerCapacity
        {
            get
            {
                return this.pasangerCapacity;
            }
            set
            {
                Validator.ValidateMinAndMaxCapacity(value, GlobalConstants.MinPassengers, GlobalConstants.MaxPassangers,
                    "vehicle");
                this.pasangerCapacity = value;
            }
        }

        public virtual decimal PricePerKilometer
        {
            get
            {
                return this.pricePerKilometer;
            }
            set
            {
                Validator.ValidateMinAndMaxPriceCapacity(value, GlobalConstants.MinPricePerKilometer, GlobalConstants.MaxPricePerKilometer);
                this.pricePerKilometer = value;
            }
        }

        public virtual VehicleType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
            }
        }

        protected abstract string PrintAdditionalInfo();

        public override string ToString()
        {
            return string.Format(this.GetType().Name + " ----\nPassenger capacity: " + this.PasangerCapacity + "\nPrice per kilometer: " +
                this.PricePerKilometer + "\nVehicle type: " + this.Type + (PrintAdditionalInfo()!=null?"\n" + PrintAdditionalInfo():""));
        }
    }
}
