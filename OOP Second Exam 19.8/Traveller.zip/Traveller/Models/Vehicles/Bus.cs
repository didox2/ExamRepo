﻿using Traveller.Models.Enumerations;
using Traveller.Models.Vehicles.Abstracts;
using Traveller.Models.Vehicles.Contracts;
using Traveller.Utils;

namespace Traveller.Models.Vehicles
{
    public class Bus : Vehicle, IBus
    {
        public Bus(int pasangerCapacity, decimal pricePerKilometer, VehicleType type) : base(pasangerCapacity, pricePerKilometer, type)
        {
            this.PasangerCapacity = pasangerCapacity;
            this.PricePerKilometer = pricePerKilometer;
        }

        public override int PasangerCapacity
        {
            get
            {
                return base.PasangerCapacity;
            }
            set
            {
                base.PasangerCapacity = value;
                Validator.ValidateMinAndMaxCapacity(value, GlobalConstants.MinBusPassangerCapacity, GlobalConstants.MaxBusPassangerCapacity, this.GetType().Name);
            }
        }

        protected override string PrintAdditionalInfo()
        {
            return null;
        }
    }
}
