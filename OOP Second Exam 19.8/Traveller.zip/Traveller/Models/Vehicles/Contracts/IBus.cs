﻿namespace Traveller.Models.Vehicles.Contracts
{
    public interface IBus : IVehicle
    {
        
    }
}