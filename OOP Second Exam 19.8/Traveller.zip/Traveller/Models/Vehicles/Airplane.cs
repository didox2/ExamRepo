﻿using Traveller.Models.Enumerations;
using Traveller.Models.Vehicles.Abstracts;
using Traveller.Models.Vehicles.Contracts;

namespace Traveller.Models.Vehicles
{
    public class Airplane : Vehicle, IAirplane
    {
        public Airplane(int pasangerCapacity, decimal pricePerKilometer, VehicleType type, bool hasFreeFood) : base(pasangerCapacity, pricePerKilometer, type)
        {
        }

        public bool HasFreeFood { get; set; }

        protected override string PrintAdditionalInfo()
        {
            return string.Format("Has free food: " + this.HasFreeFood);
        }
    }
}
