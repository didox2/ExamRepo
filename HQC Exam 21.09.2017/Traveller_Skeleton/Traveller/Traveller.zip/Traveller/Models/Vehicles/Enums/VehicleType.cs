﻿namespace Traveller.Models.Vehicles.Enums
{
    public enum VehicleType
    {
        Land = 0,
        Air = 1,
        Sea = 2
    }
}
